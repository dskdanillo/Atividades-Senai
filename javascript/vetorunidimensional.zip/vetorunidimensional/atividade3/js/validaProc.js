function validaProc(){


        let i;
        let quadrado=0
        let num=[];
     
 
        
        for (i=0 ; i<10; i++){
    
                quadrado = i*i
                console.log("O quadrado da posição: "+i+ " é : " +quadrado)
    
        }
                    

    return false;
    
    }
    



